# Invitación de boda — Paola & Giancarlo

Estructura:
- index.html
- /img -> Reemplaza las imágenes por tus archivos reales (mismos nombres).
- /audio/song.mp3 -> Reemplaza por tu pista (opcional).

Abrir `index.html` en un navegador moderno. Las animaciones se activan al hacer scroll.
El botón de música funciona cuando haces clic (no autoplay).

Para mapas, los botones abren un modal con Waze o Google Maps usando los plus codes/direcciones.
El formulario de RSVP abre WhatsApp con el mensaje prellenado (no envía datos al servidor).
