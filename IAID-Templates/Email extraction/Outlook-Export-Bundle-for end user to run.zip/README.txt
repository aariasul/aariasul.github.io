Outlook Export Bundle
=====================

Files:
  - Export-Outlook-Emails-ByCompany-AllPST.ps1  (the exporter)
  - Run-Export-OutlookContacts.bat              (one-click launcher that shows a menu)
  - README.txt                                  (this file)

What it does
------------
- Scans Outlook "Sent Items" and "Inbox" across all stores, including local PSTs you have open.
- Limits scanning to the last N days (you choose in the menu).
- Exports contact rows to CSV and/or Excel (.xlsx).
- Header row is exactly: name,email,company,Direction,Store,FirstFolder

How to use (one-click)
----------------------
1) Make sure Outlook is open and any PSTs you want scanned are attached.
2) Double-click "Run-Export-OutlookContacts.bat".
3) In the menu, choose:
   - Output Type: CSV, Excel, or Both
   - Days to scan: 60, 365, or 600
   - Folders: Include Inbox and/or Include Sent Items
   - Optional: Browse to choose a custom file name
4) Click Start. When finished, a path to the saved file(s) is shown in the PowerShell window.

Notes
-----
- Excel (.xlsx) requires Microsoft Excel installed. If Excel is not available, CSV still works.
- By default, files are saved to your Documents folder.
- If Windows blocks the script: Right-click the .ps1 file, choose Properties, check "Unblock", OK.
- The .bat launcher runs with a temporary ExecutionPolicy bypass and does not change your computer's policy.
