# Export-Outlook-Emails-ByCompany-AllPST.ps1
# Scans all Outlook stores (including local PSTs you have open in Outlook),
# in Sent Items and/or Inbox, limits by last N days, shows progress,
# and exports a CSV and/or XLSX file of unique contacts.
#
# Header row is exactly:
#   name,email,company,Direction,Store,FirstFolder
#
# Interactive menu (WinForms) with radio buttons for Output Type and DaysBack.
# - If you run the script with no parameters (double-click or Run with PowerShell), the menu appears.
# - If you pass parameters on the command line, the menu is skipped.
# - You can force the menu with -Interactive.
#
# Usage examples:
#   .\Export-Outlook-Emails-ByCompany-AllPST.ps1 -Interactive
#   .\Export-Outlook-Emails-ByCompany-AllPST.ps1 -DaysBack 30 -OutputType XLSX
#   .\Export-Outlook-Emails-ByCompany-AllPST.ps1 -DaysBack 90 -OutputType Both -OutputFile "C:\Temp\recipients.xlsx"
#   .\Export-Outlook-Emails-ByCompany-AllPST.ps1 -IncludeInbox:$false -OutputType CSV
#
# Note: XLSX export uses Excel COM automation and requires Microsoft Excel installed.
#       If Excel is not available, CSV export still works.

[CmdletBinding()]
param(
    [Parameter(Mandatory=$false)]
    [ValidateRange(1,3650)]
    [int]$DaysBack = 180,

    [Parameter(Mandatory=$false)]
    [string]$OutputFile,

    [Parameter(Mandatory=$false)]
    [ValidateSet("CSV","XLSX","Both")]
    [string]$OutputType = "CSV",

    [Parameter(Mandatory=$false)]
    [bool]$IncludeSent = $true,

    [Parameter(Mandatory=$false)]
    [bool]$IncludeInbox = $true,

    [Parameter(Mandatory=$false)]
    [switch]$Interactive
)

function Show-ParamMenu {
    try {
        Add-Type -AssemblyName System.Windows.Forms | Out-Null
        Add-Type -AssemblyName System.Drawing       | Out-Null
    } catch {
        Write-Warning "Could not load WinForms assemblies. Run with Windows PowerShell 5.1 or use command-line parameters."
        return $null
    }

    $form = New-Object System.Windows.Forms.Form
    $form.Text = "Export Outlook Contacts"
    $form.StartPosition = "CenterScreen"
    $form.Size = New-Object System.Drawing.Size(480, 360)
    $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false
    $form.Topmost = $true

    $grpType = New-Object System.Windows.Forms.GroupBox
    $grpType.Text = "Output Type"
    $grpType.Location = New-Object System.Drawing.Point(12, 12)
    $grpType.Size = New-Object System.Drawing.Size(210, 110)

    $rbCsv  = New-Object System.Windows.Forms.RadioButton
    $rbCsv.Text = "CSV"
    $rbCsv.Location = New-Object System.Drawing.Point(16, 24)
    $rbCsv.Checked = $true

    $rbXlsx = New-Object System.Windows.Forms.RadioButton
    $rbXlsx.Text = "Excel (.xlsx)"
    $rbXlsx.Location = New-Object System.Drawing.Point(16, 48)

    $rbBoth = New-Object System.Windows.Forms.RadioButton
    $rbBoth.Text = "Both (CSV + XLSX)"
    $rbBoth.Location = New-Object System.Drawing.Point(16, 72)

    $grpType.Controls.AddRange(@($rbCsv,$rbXlsx,$rbBoth))

    $grpDays = New-Object System.Windows.Forms.GroupBox
    $grpDays.Text = "Days to scan"
    $grpDays.Location = New-Object System.Drawing.Point(246, 12)
    $grpDays.Size = New-Object System.Drawing.Size(210, 110)

    $rb60  = New-Object System.Windows.Forms.RadioButton
    $rb60.Text = "60 days"
    $rb60.Location = New-Object System.Drawing.Point(16, 24)
    $rb60.Checked = $true

    $rb365 = New-Object System.Windows.Forms.RadioButton
    $rb365.Text = "365 days"
    $rb365.Location = New-Object System.Drawing.Point(16, 48)

    $rb600 = New-Object System.Windows.Forms.RadioButton
    $rb600.Text = "600 days"
    $rb600.Location = New-Object System.Drawing.Point(16, 72)

    $grpDays.Controls.AddRange(@($rb60,$rb365,$rb600))

    $grpFolders = New-Object System.Windows.Forms.GroupBox
    $grpFolders.Text = "Folders"
    $grpFolders.Location = New-Object System.Drawing.Point(12, 132)
    $grpFolders.Size = New-Object System.Drawing.Size(210, 90)

    $cbInbox = New-Object System.Windows.Forms.CheckBox
    $cbInbox.Text = "Include Inbox"
    $cbInbox.Location = New-Object System.Drawing.Point(16, 24)
    $cbInbox.Checked = $true

    $cbSent = New-Object System.Windows.Forms.CheckBox
    $cbSent.Text = "Include Sent Items"
    $cbSent.Location = New-Object System.Drawing.Point(16, 48)
    $cbSent.Checked = $true

    $grpFolders.Controls.AddRange(@($cbInbox,$cbSent))

    $lblPath = New-Object System.Windows.Forms.Label
    $lblPath.Text = "Output file (optional):"
    $lblPath.Location = New-Object System.Drawing.Point(12, 232)
    $lblPath.Size = New-Object System.Drawing.Size(150, 18)

    $txtPath = New-Object System.Windows.Forms.TextBox
    $txtPath.Location = New-Object System.Drawing.Point(12, 252)
    $txtPath.Size = New-Object System.Drawing.Size(370, 22)

    $btnBrowse = New-Object System.Windows.Forms.Button
    $btnBrowse.Text = "Browse..."
    $btnBrowse.Location = New-Object System.Drawing.Point(388, 250)
    $btnBrowse.Size = New-Object System.Drawing.Size(68, 24)

    $sfd = New-Object System.Windows.Forms.SaveFileDialog
    $sfd.Title = "Choose output file name"
    $sfd.Filter = "CSV or Excel|*.csv;*.xlsx|CSV|*.csv|Excel Workbook|*.xlsx"
    $sfd.AddExtension = $true
    $sfd.OverwritePrompt = $true

    $btnBrowse.Add_Click({
        if ($sfd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            $txtPath.Text = $sfd.FileName
        }
    })

    $btnOk = New-Object System.Windows.Forms.Button
    $btnOk.Text = "Start"
    $btnOk.Location = New-Object System.Drawing.Point(246, 290)
    $btnOk.Size = New-Object System.Drawing.Size(100, 28)

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = "Cancel"
    $btnCancel.Location = New-Object System.Drawing.Point(356, 290)
    $btnCancel.Size = New-Object System.Drawing.Size(100, 28)

    $result = $null

    $btnOk.Add_Click({
        $selType = "CSV"
        if ($rbXlsx.Checked) { $selType = "XLSX" }
        if ($rbBoth.Checked) { $selType = "Both" }

        $selDays = 60
        if ($rb365.Checked) { $selDays = 365 }
        if ($rb600.Checked) { $selDays = 600 }

        $result = @{
            OutputType   = $selType
            DaysBack     = [int]$selDays
            IncludeInbox = [bool]$cbInbox.Checked
            IncludeSent  = [bool]$cbSent.Checked
            OutputFile   = $txtPath.Text
        }
        $form.Close()
    })

    $btnCancel.Add_Click({
        $result = $null
        $form.Close()
    })

    $form.Controls.AddRange(@($grpType,$grpDays,$grpFolders,$lblPath,$txtPath,$btnBrowse,$btnOk,$btnCancel))

    [void]$form.ShowDialog()
    return $result
}

$shouldShowMenu = $false
if ($Interactive) { $shouldShowMenu = $true }
elseif ($PSBoundParameters.Count -eq 0) { $shouldShowMenu = $true }

if ($shouldShowMenu) {
    $menuResult = Show-ParamMenu
    if ($menuResult -eq $null) {
        Write-Host "Canceled." -ForegroundColor Yellow
        return
    }
    if ($menuResult.OutputType)   { $OutputType   = $menuResult.OutputType }
    if ($menuResult.DaysBack)     { $DaysBack     = [int]$menuResult.DaysBack }
    if ($menuResult.ContainsKey("IncludeInbox")) { $IncludeInbox = [bool]$menuResult.IncludeInbox }
    if ($menuResult.ContainsKey("IncludeSent"))  { $IncludeSent  = [bool]$menuResult.IncludeSent }
    if ($menuResult.OutputFile -and $menuResult.OutputFile.Trim().Length -gt 0) { $OutputFile = $menuResult.OutputFile }
}

if (-not $IncludeSent -and -not $IncludeInbox) {
    Write-Error "Both IncludeSent and IncludeInbox are false. Enable at least one."
    exit 1
}

function Resolve-OutputPaths {
    param(
        [string]$OutputFileParam,
        [string]$OutputTypeParam
    )
    $docs = [Environment]::GetFolderPath([Environment+SpecialFolder]::MyDocuments)

    $saveCsv  = $false
    $saveXlsx = $false
    if ($OutputTypeParam -eq "CSV")  { $saveCsv = $true }
    if ($OutputTypeParam -eq "XLSX") { $saveXlsx = $true }
    if ($OutputTypeParam -eq "Both") { $saveCsv = $true; $saveXlsx = $true }

    $defaultBase = Join-Path -Path $docs -ChildPath "Outlook_SentInbox_Recipients"

    $csvPath  = $null
    $xlsxPath = $null

    if ([string]::IsNullOrWhiteSpace($OutputFileParam)) {
        if ($saveCsv)  { $csvPath  = $defaultBase + ".csv" }
        if ($saveXlsx) { $xlsxPath = $defaultBase + ".xlsx" }
    } else {
        $ext = [System.IO.Path]::GetExtension($OutputFileParam)
        $dir = [System.IO.Path]::GetDirectoryName($OutputFileParam)
        if ([string]::IsNullOrWhiteSpace($dir)) { $dir = $docs }
        $nameNoExt = [System.IO.Path]::GetFileNameWithoutExtension($OutputFileParam)

        if ($saveCsv -and $saveXlsx) {
            if ([string]::IsNullOrWhiteSpace($ext)) {
                $csvPath  = Join-Path $dir ($nameNoExt + ".csv")
                $xlsxPath = Join-Path $dir ($nameNoExt + ".xlsx")
            } elseif ($ext.ToLower() -eq ".csv") {
                $csvPath  = Join-Path $dir ($nameNoExt + ".csv")
                $xlsxPath = Join-Path $dir ($nameNoExt + ".xlsx")
            } elseif ($ext.ToLower() -eq ".xlsx") {
                $csvPath  = Join-Path $dir ($nameNoExt + ".csv")
                $xlsxPath = Join-Path $dir ($nameNoExt + ".xlsx")
            } else {
                $csvPath  = Join-Path $dir ($nameNoExt + ".csv")
                $xlsxPath = Join-Path $dir ($nameNoExt + ".xlsx")
            }
        } elseif ($saveCsv) {
            if ($ext.ToLower() -eq ".csv") {
                $csvPath = Join-Path $dir ($nameNoExt + ".csv")
            } elseif ([string]::IsNullOrWhiteSpace($ext)) {
                $csvPath = Join-Path $dir ($nameNoExt + ".csv")
            } else {
                $csvPath = Join-Path $dir ($nameNoExt + ".csv")
            }
        } elseif ($saveXlsx) {
            if ($ext.ToLower() -eq ".xlsx") {
                $xlsxPath = Join-Path $dir ($nameNoExt + ".xlsx")
            } elseif ([string]::IsNullOrWhiteSpace($ext)) {
                $xlsxPath = Join-Path $dir ($nameNoExt + ".xlsx")
            } else {
                $xlsxPath = Join-Path $dir ($nameNoExt + ".xlsx")
            }
        }
    }

    return @{
        CsvPath  = $csvPath
        XlsxPath = $xlsxPath
        SaveCsv  = $saveCsv
        SaveXlsx = $saveXlsx
    }
}

$paths = Resolve-OutputPaths -OutputFileParam $OutputFile -OutputTypeParam $OutputType
$CsvPath  = $paths.CsvPath
$XlsxPath = $paths.XlsxPath
$DoCsv    = [bool]$paths.SaveCsv
$DoXlsx   = [bool]$paths.SaveXlsx

$cutoff = (Get-Date).AddDays(-$DaysBack)
$culture = New-Object System.Globalization.CultureInfo("en-US")
$cutoffStr = $cutoff.ToString("MM/dd/yyyy hh:mm tt", $culture)

$olFolderInbox = 6
$olFolderSentMail = 5
$olMailItemClassId = 43

function Get-SmtpFromRecipient {
    param([Parameter(Mandatory=$true)] $Recipient)
    try {
        $addrEntry = $Recipient.AddressEntry
        if ($addrEntry -ne $null) {
            if ($addrEntry.Type -eq "EX") {
                $exUser = $addrEntry.GetExchangeUser()
                if ($exUser -and $exUser.PrimarySmtpAddress) { return $exUser.PrimarySmtpAddress }
            }
            if ($addrEntry.Address) { return $addrEntry.Address }
        }
        return $Recipient.Address
    } catch {
        return $null
    }
}

function Get-SmtpFromSender {
    param([Parameter(Mandatory=$true)] $Mail)
    try {
        if ($Mail.SenderEmailType -eq "EX") {
            $exUser = $Mail.Sender.GetExchangeUser()
            if ($exUser -and $exUser.PrimarySmtpAddress) { return $exUser.PrimarySmtpAddress }
        }
        if ($Mail.SenderEmailAddress) {
            if ($Mail.SenderEmailAddress -match "@") { return $Mail.SenderEmailAddress }
        }
        $pa = $Mail.PropertyAccessor
        $PR_SMTP = "http://schemas.microsoft.com/mapi/proptag/0x39FE001E"
        $smtp = $pa.GetProperty($PR_SMTP)
        if ($smtp -and ($smtp -match "@")) { return $smtp }
        return $null
    } catch {
        return $null
    }
}

function Get-DomainFromEmail {
    param([string]$Email)
    if ([string]::IsNullOrWhiteSpace($Email)) { return $null }
    $clean = $Email.Trim().ToLower() -replace "^mailto:", ""
    if ($clean -match "^[^@]+@(.+)$") { return $Matches[1] } else { return $null }
}

$results = @{}
function Add-Result {
    param(
        [string]$Name,
        [string]$Email,
        [string]$Company,
        [string]$Direction,
        [string]$StoreName,
        [string]$FolderName
    )
    if ([string]::IsNullOrWhiteSpace($Email)) { return }
    $key = $Email.ToLower()
    if (-not $results.ContainsKey($key)) {
        $results[$key] = [PSCustomObject]@{
            Name        = $Name
            Email       = $Email
            Company     = $Company
            Direction   = $Direction
            Store       = $StoreName
            FirstFolder = $FolderName
        }
    }
}

try {
    $Outlook = New-Object -ComObject Outlook.Application
    $Namespace = $Outlook.GetNamespace("MAPI")
} catch {
    Write-Error "Unable to start Outlook COM object. Make sure Outlook desktop is installed and running."
    exit 1
}

Write-Host "Enumerating all Outlook stores (including open PST files)..." -ForegroundColor Cyan

try {
    $stores = @()
    for ($s = 1; $s -le $Namespace.Stores.Count; $s++) {
        $stores += $Namespace.Stores.Item($s)
    }
} catch {
    Write-Error "Failed to enumerate Outlook stores: $_"
    exit 1
}

if (-not $stores -or $stores.Count -eq 0) {
    Write-Warning "No stores found. Open Outlook and attach at least one mailbox or PST."
    exit 0
}

$storeIndex = 0
foreach ($store in $stores) {
    $storeIndex++
    $storeName = $store.DisplayName
    $storePath = ""
    try { $storePath = $store.FilePath } catch { $storePath = "" }
    $isPst = $false
    if ($storePath -and ($storePath -match "\.pst$")) { $isPst = $true }

    $pstTag = ""
    if ($isPst) { $pstTag = "(PST)" }
    Write-Host ("- Store [{0}/{1}]: {2} {3}" -f $storeIndex, $stores.Count, $storeName, $pstTag) -ForegroundColor Yellow

    $foldersToScan = @()
    if ($IncludeSent)  { try { $foldersToScan += $store.GetDefaultFolder($olFolderSentMail) } catch {} }
    if ($IncludeInbox) { try { $foldersToScan += $store.GetDefaultFolder($olFolderInbox)     } catch {} }

    foreach ($folder in $foldersToScan) {
        if (-not $folder) { continue }

        $folderName = $folder.Name
        $activity = "Scanning: $storeName"
        $status = "Folder: $folderName | Since: $cutoffStr"

        $items = $folder.Items
        if (-not $items) { continue }

        try {
            if ($folder.EntryID -eq $store.GetDefaultFolder($olFolderInbox).EntryID) {
                $items.Sort("[ReceivedTime]", $true)
                $restricted = $items.Restrict("[ReceivedTime] >= '$cutoffStr'")
            } elseif ($folder.EntryID -eq $store.GetDefaultFolder($olFolderSentMail).EntryID) {
                $items.Sort("[SentOn]", $true)
                $restricted = $items.Restrict("[SentOn] >= '$cutoffStr'")
            } else {
                $items.Sort("[ReceivedTime]", $true)
                $restricted = $items.Restrict("[ReceivedTime] >= '$cutoffStr'")
            }
        } catch {
            Write-Warning "Restrict() failed on $storeName\$folderName. Scanning all items (slower). Error: $_"
            $restricted = $items
        }

        $total = 0
        try { $total = $restricted.Count } catch { $total = 0 }
        if ($total -eq 0) {
            Write-Host ("   * {0}: 0 items after filter." -f $folderName) -ForegroundColor DarkGray
            continue
        }

        Write-Host ("   * {0}: scanning {1} item(s)..." -f $folderName, $total) -ForegroundColor DarkGray

        for ($i = 1; $i -le $total; $i++) {
            try { $mail = $restricted.Item($i) } catch { continue }
            try { if ($mail.Class -ne $olMailItemClassId) { continue } } catch { continue }

            $percent = [int](($i / $total) * 100)
            Write-Progress -Activity $activity -Status "$status - $i / $total" -PercentComplete $percent

            if ($IncludeSent -and ($folder.EntryID -eq ($store.GetDefaultFolder($olFolderSentMail).EntryID))) {
                try {
                    $recips = $mail.Recipients
                    if ($recips -and $recips.Count -gt 0) {
                        for ($r = 1; $r -le $recips.Count; $r++) {
                            $recip = $recips.Item($r)
                            $name = $recip.Name
                            $email = Get-SmtpFromRecipient -Recipient $recip
                            $domain = Get-DomainFromEmail -Email $email
                            Add-Result -Name $name -Email $email -Company $domain -Direction "Sent" -StoreName $storeName -FolderName $folderName
                        }
                    }
                } catch {}
            }

            if ($IncludeInbox -and ($folder.EntryID -eq ($store.GetDefaultFolder($olFolderInbox).EntryID))) {
                try {
                    $name = $mail.SenderName
                    $email = Get-SmtpFromSender -Mail $mail
                    $domain = Get-DomainFromEmail -Email $email
                    Add-Result -Name $name -Email $email -Company $domain -Direction "Inbox" -StoreName $storeName -FolderName $folderName
                } catch {}
            }
        }

        Write-Progress -Activity $activity -Completed
    }
}

function Export-ToCsvFile {
    param(
        [System.Collections.IEnumerable]$Rows,
        [string]$Path
    )
    $Rows | Select-Object @{
            Name = "name"; Expression = { $_.Name }
        }, @{
            Name = "email"; Expression = { $_.Email }
        }, @{
            Name = "company"; Expression = { $_.Company }
        }, Direction, Store, FirstFolder |
        Export-Csv -Path $Path -NoTypeInformation -Encoding UTF8
    Write-Host ("CSV saved to: {0}" -f $Path) -ForegroundColor Green
}

function Export-ToXlsxFile {
    param(
        [System.Collections.IList]$RowsList,
        [string]$Path
    )
    $excel = $null
    $wb = $null
    $ws = $null
    try {
        Add-Type -AssemblyName Microsoft.Office.Interop.Excel -ErrorAction SilentlyContinue | Out-Null
        $excel = New-Object -ComObject Excel.Application
    } catch {
        Write-Warning "Excel COM automation is not available. XLSX export skipped. Error: $_"
        return
    }
    try {
        $excel.Visible = $false
        $wb = $excel.Workbooks.Add()
        $ws = $wb.Worksheets.Item(1)

        $headers = @("name","email","company","Direction","Store","FirstFolder")
        for ($c = 1; $c -le $headers.Count; $c++) {
            $ws.Cells.Item(1, $c) = $headers[$c-1]
        }

        $rowCount = $RowsList.Count
        for ($r = 0; $r -lt $rowCount; $r++) {
            $row = $RowsList[$r]
            $ws.Cells.Item($r+2, 1) = [string]$row.Name
            $ws.Cells.Item($r+2, 2) = [string]$row.Email
            $ws.Cells.Item($r+2, 3) = [string]$row.Company
            $ws.Cells.Item($r+2, 4) = [string]$row.Direction
            $ws.Cells.Item($r+2, 5) = [string]$row.Store
            $ws.Cells.Item($r+2, 6) = [string]$row.FirstFolder
        }

        $ws.UsedRange.Columns.AutoFit() | Out-Null

        $xlOpenXMLWorkbook = 51
        $wb.SaveAs($Path, $xlOpenXMLWorkbook)
        $wb.Close($true)
        $excel.Quit()
        Write-Host ("XLSX saved to: {0}" -f $Path) -ForegroundColor Green
    } catch {
        Write-Warning "Failed to save XLSX: $_"
        if ($wb -ne $null) { try { $wb.Close($false) } catch {} }
        if ($excel -ne $null) { try { $excel.Quit() } catch {} }
    } finally {
        if ($ws -ne $null) { try { [System.Runtime.InteropServices.Marshal]::ReleaseComObject($ws) | Out-Null } catch {} }
        if ($wb -ne $null) { try { [System.Runtime.InteropServices.Marshal]::ReleaseComObject($wb) | Out-Null } catch {} }
        if ($excel -ne $null) { try { [System.Runtime.InteropServices.Marshal]::ReleaseComObject($excel) | Out-Null } catch {} }
        [GC]::Collect()
        [GC]::WaitForPendingFinalizers()
    }
}

$ordered = $results.Values | Sort-Object Company, Name, Email
$orderedList = @()
$orderedList += $ordered

if ($DoCsv -and $CsvPath) {
    Export-ToCsvFile -Rows $ordered -Path $CsvPath
}
if ($DoXlsx -and $XlsxPath) {
    Export-ToXlsxFile -RowsList $orderedList -Path $XlsxPath
}

Write-Host ""
Write-Host ("Rows exported: {0}" -f $results.Count)
if ($DoCsv -and $CsvPath)  { Write-Host ("CSV path : {0}" -f $CsvPath) }
if ($DoXlsx -and $XlsxPath){ Write-Host ("XLSX path: {0}" -f $XlsxPath) }
