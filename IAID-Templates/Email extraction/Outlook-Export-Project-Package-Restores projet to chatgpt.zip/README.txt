Outlook Export Bundle
=====================
Files:
  - Export-Outlook-Emails-ByCompany-AllPST.ps1  (the exporter with menu)
  - Run-Export-OutlookContacts.bat              (one-click launcher)
  - PROJECT_SPEC.txt                            (technical spec)
  - RESTORE_GUIDE.txt                           (how to reuse this later)

Use:
1) Open Outlook. Attach the PSTs you want scanned.
2) Double-click Run-Export-OutlookContacts.bat.
3) Pick output type (CSV / Excel / Both), days (60 / 365 / 600), and folders.
4) Click Start. Files are saved in Documents by default.
Headers are exactly: name,email,company,Direction,Store,FirstFolder
